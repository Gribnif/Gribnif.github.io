/*
	MultiMouse - bind MULTIple mice into a MOUSE -
	Copyright (C) 1995 Takashi MANABE (manabe@papilio.tutics.tut.ac.jp)

	MultiMouse is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published
	by the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	MultiMouse is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
	See the GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
#define DEBUG	1
*/


#define	VERSION		"1.10"
#ifndef	MAX_MICE
#define	MAX_MICE	3
#endif

/* DON'T EDIT */

#ifndef	MOUSE_FIFO
#define	MOUSE_FIFO	"/dev/mumse"
#endif

#ifndef X10_FIFO      
#define X10_FIFO      "/dev/x10fifo"
#endif

#define MOUSE_PKSIZE	5
#define	PATH_PID	LOCKDIR"/MultiMouse.pid"

struct mouseProtocol {
    u_char hmask, hid, dmask, len;
};

struct mouseInfo {
    int fd, noemu;
    struct mouseProtocol mp;
    u_char type;
};

enum {
    MOUSE_MICROSOFT,
    MOUSE_BUSMOUSE,
    MOUSE_MMSERIES,
    MOUSE_LOGITECH,
    MOUSE_PS2,
    MOUSE_MOUSESYS,
    MOUSE_X10,
    MOUSE_X10S,
    MOUSE_NOMOUSE
};

typedef enum {FALSE, TRUE} bool;

extern int msFifo;
extern int x10Fifo;
extern struct mouseInfo msInfo[];
